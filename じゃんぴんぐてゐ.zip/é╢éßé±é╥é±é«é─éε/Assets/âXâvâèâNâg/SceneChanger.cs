﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(Button))]
public class SceneChanger : UIBehaviour {

    /// <summary>
    /// シーン名格納
    /// </summary>
    public string nextScene;

    /// <summary>
    /// クリック時、SceneChangeメソッドの呼び出し
    /// </summary>
    protected override void Start()
    {
        base.Start();

        GetComponent<Button>().onClick.AddListener(SceneChange);
    }

    /// <summary>
    /// シーン遷移
    /// </summary>
    void SceneChange(){
            SceneManager.LoadScene(nextScene);
    }
}
