﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// AudioSourceコンポーネント追加
/// </summary>
[RequireComponent(typeof(AudioSource))]
public class PlayerController : MonoBehaviour
{

    /// <summary>
    /// 変数の定義
    /// </summary>
    public float flap = 350f;
    public float flap_end = 1;
    public const int MAX_JUMP_COUNT = 2;    //2段ジャンプカウント

    private int jump_count = 0;
    private bool isJump = false;

    private Rigidbody2D rb2d;
    private Animator anim;

    /// <summary>
    /// Audio定義
    /// </summary>
    public AudioClip JumpSE;                //ジャンプSE
    public AudioClip LandSE;                //着地SE

    public AudioClip Tread_kedamaSE;        //毛玉踏んだ時のSE

    private AudioSource mAudio;

    /// <summary>
    /// コンポーネント読込
    /// </summary>
    // Use this for initialization
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        mAudio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        /// <summary>
        /// キーボード操作
        /// </summary>
        if (Input.GetKeyDown("space") && jump_count < MAX_JUMP_COUNT)
        {//2段ジャンプ後動作を制限

            //ジャンプアニメーション分岐
            switch (jump_count) {
                case 0:
                    PlayerVoice(JumpSE);            //SE再生
                    anim.SetBool("Jump01", true);   //ジャンプ01再生
                    break;

                case 1:
                    PlayerVoice(JumpSE);            //SE再生
                    anim.SetBool("Jump02", true);   //ジャンプ02再生
                    anim.SetBool("Jump01", false);
                    break;

                default:
                    break;
            }
            isJump = true;
        }
    }

    void FixedUpdate() {

        if (isJump) {
            //速度リセット＆挙動を1回目と同じにする
            rb2d.velocity = Vector2.zero;

            rb2d.AddForce(Vector2.up * flap);       //ジャンプ処理
            jump_count++;                           //カウント
            
            isJump = false;                         //ジャンプ動作許可

        }
    }

    /// <summary>
    /// 地面判定
    /// </summary>
    private void OnCollisionEnter2D(Collision2D coln2d)
    {
        /// <summary>
        /// 地面についたら2段ジャンプできるようにする
        /// </summary>
        if (coln2d.gameObject.tag == "Ground") {//地面に着地

            //ジャンプアニメ初期化
            if (jump_count == 1) {

                PlayerVoice(LandSE);            //着地SE
                anim.SetBool("Jump01", false);
            }
            else if (jump_count == 2) {

                PlayerVoice(LandSE);            //着地SE
                anim.SetBool("Jump02", false);
            }

            jump_count = 0;
        }

        /// <summary>
        /// Enemyと接触
        /// </summary>
        if (coln2d.gameObject.tag == "Enemy") {
                //Player座標取得
            Vector2 player_pos = GameObject.FindGameObjectWithTag("Player").transform.position;
                //Enemy座標取得
            Vector2 Ekedama_pos = GameObject.FindGameObjectWithTag("Enemy").transform.position;

            /// <summary>
            /// 上から接触
            /// </summary>
            if (player_pos.y > Ekedama_pos.y)
            {
                    //敵削除
                Destroy(coln2d.gameObject);
                    //踏んだ(毛玉)サウンド
                PlayerVoice(Tread_kedamaSE);
                    //ジャンプさせる＆カウント更新
                jump_count = 1;
                anim.SetBool("Jump02", false);              //2段ジャンプ後のアニメ補正用

                rb2d.AddForce(Vector2.up * flap);           //ジャンプ処理
                anim.SetBool("Jump01", true);               //ジャンプ01再生

            }

        }
    }

    /// <summary>
    /// Audioウェイト入れる
    /// </summary>
    void PlayerVoice(AudioClip clip) {
        
        //音消去
        mAudio.Stop ();

        //音再生
        mAudio.PlayOneShot(clip);
    }
}
