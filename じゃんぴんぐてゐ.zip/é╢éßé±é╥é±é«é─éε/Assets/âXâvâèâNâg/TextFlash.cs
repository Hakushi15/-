﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextFlash : MonoBehaviour {

    public float flashIntarval;

    float delta = 0;


	// Update is called once per frame
	void Update () {
        /// <summary>
        /// 次フレームまでの時間
        /// </summary>
        this.delta += Time.deltaTime;

        /// <summary>
        /// テキスト点滅処理
        /// </summary>
        if(this.delta > this.flashIntarval) {

            float alpha = GetComponent<CanvasRenderer>().GetAlpha();

            if(alpha == 1.0f) {
                GetComponent<CanvasRenderer>().SetAlpha(0.0f);
            }
            else {
                GetComponent<CanvasRenderer>().SetAlpha(1.0f);
            }

            this.delta = 0;
        }
    }
}
